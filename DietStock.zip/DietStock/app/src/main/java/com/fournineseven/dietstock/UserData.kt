package com.fournineseven.dietstock

object User{
    var step = 0
    var sensorStep = 0
    var sensorKcal = 0.0f
    var kcal = 0.0f
    var PKcal = 0.0f
}