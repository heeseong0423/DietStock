package com.fournineseven.dietstock.config;

public class TaskServer {
    public static final String base_url ="http://497.iptime.org/";
}