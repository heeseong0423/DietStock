package com.fournineseven.dietstock.model.dataset;

public class piechartDataset {
    String food_name;
    int cnt;
    public piechartDataset(String food_name, int cnt){
        this.food_name = food_name;
        this.cnt = cnt;
    }
}
